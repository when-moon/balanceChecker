var require = meteorInstall({"lib":{"lib.js":function(){

/////////////////////////////////////////////////////////////////////////////////////
//                                                                                 //
// lib/lib.js                                                                      //
//                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////
                                                                                   //
if (Meteor.isServer) {} else {
    if (typeof web3 !== 'undefined') {
        web3 = new Web3(web3.currentProvider);
    } else {
        // set the provider you want from Web3.providers
        web3 = new Web3(new Web3.providers.HttpProvider("http://localhost:8545"));
    }
}
/////////////////////////////////////////////////////////////////////////////////////

}},"server":{"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////
//                                                                                 //
// server/main.js                                                                  //
//                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////
                                                                                   //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
Meteor.startup(() => {// code to run on server at startup
});
/////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./lib/lib.js");
require("./server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvbGliL2xpYi5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsiTWV0ZW9yIiwiaXNTZXJ2ZXIiLCJ3ZWIzIiwiV2ViMyIsImN1cnJlbnRQcm92aWRlciIsInByb3ZpZGVycyIsIkh0dHBQcm92aWRlciIsIm1vZHVsZSIsIndhdGNoIiwicmVxdWlyZSIsInYiLCJzdGFydHVwIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLElBQUlBLE9BQU9DLFFBQVgsRUFBcUIsQ0FFcEIsQ0FGRCxNQUVPO0FBQ0gsUUFBSSxPQUFPQyxJQUFQLEtBQWdCLFdBQXBCLEVBQWlDO0FBQzdCQSxlQUFPLElBQUlDLElBQUosQ0FBU0QsS0FBS0UsZUFBZCxDQUFQO0FBQ0gsS0FGRCxNQUVPO0FBQ0g7QUFDQUYsZUFBTyxJQUFJQyxJQUFKLENBQVMsSUFBSUEsS0FBS0UsU0FBTCxDQUFlQyxZQUFuQixDQUFnQyx1QkFBaEMsQ0FBVCxDQUFQO0FBQ0g7QUFDSixDOzs7Ozs7Ozs7OztBQ1RELElBQUlOLE1BQUo7QUFBV08sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDVCxTQUFPVSxDQUFQLEVBQVM7QUFBQ1YsYUFBT1UsQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUVYVixPQUFPVyxPQUFQLENBQWUsTUFBTSxDQUNuQjtBQUNELENBRkQsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaWYgKE1ldGVvci5pc1NlcnZlcikge1xuXG59IGVsc2Uge1xuICAgIGlmICh0eXBlb2Ygd2ViMyAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgd2ViMyA9IG5ldyBXZWIzKHdlYjMuY3VycmVudFByb3ZpZGVyKTtcbiAgICB9IGVsc2Uge1xuICAgICAgICAvLyBzZXQgdGhlIHByb3ZpZGVyIHlvdSB3YW50IGZyb20gV2ViMy5wcm92aWRlcnNcbiAgICAgICAgd2ViMyA9IG5ldyBXZWIzKG5ldyBXZWIzLnByb3ZpZGVycy5IdHRwUHJvdmlkZXIoXCJodHRwOi8vbG9jYWxob3N0Ojg1NDVcIikpO1xuICAgIH1cbn0iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcblxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xuICAvLyBjb2RlIHRvIHJ1biBvbiBzZXJ2ZXIgYXQgc3RhcnR1cFxufSk7XG4iXX0=
